import 'dart:convert';

import 'package:flutter/material.dart';
import 'buyer_itemdetails.dart';
import 'services/api6.dart';

void main() => runApp(Buyer());

class Buyer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: BuyerDashboard(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class BuyerDashboard extends StatefulWidget {
  @override
  _BuyerDashboardState createState() => _BuyerDashboardState();
}

class _BuyerDashboardState extends State<BuyerDashboard> {
 
 bool _isLoading = false;
  List<CropInformation> _cropData = [];
  @override
  void initState() {
    super.initState();
    _fetchCropData();
    // Call your API here or perform any other initialization tasks
  }

  Future<void> _fetchCropData() async {
    setState(() {
      _isLoading = true;
    });
        try {
      // Call the API to fetch crop data
      dynamic responseData = await Api6.mycrops();

      // Convert the dynamic list to a list of CropInformation objects
      List<CropInformation> crops = [];
      for (var cropData in responseData) {
        CropInformation crop = CropInformation.fromJson(cropData);
        crops.add(crop);
      }

      // Update _cropData with fetched data
      setState(() {
        _cropData = crops;
      });
    } catch (e) {
      // Handle any errors that occur during the API call
      print('Error fetching crop data: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFFC4E977), // Start color
                Color(0xFF6E8343), // End color
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Column(
            children: [
              DashboardHeader(),
              DashboardGrid(
                  cropData:
                      _cropData), // This is the correct way to add DashboardGrid
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomBar(),
    );
  }
}

class DashboardHeader extends StatelessWidget {
  var userId = 'sjhs921';
  var userName = 'AGROMOB';

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFFC4E977), // Start color
            Color(0xFF6E8343), // End color
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      padding: EdgeInsets.all(20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: Color.fromARGB(255, 25, 49, 26),
            child: Icon(
              Icons.person,
              size: 40,
              color: Color(0xFF6E8343),
            ),
          ),
          SizedBox(width: 20),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$userId',
                // $userId',
                // style:
                 style: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              // Text(
              //   'Username: $userName',
              //   style: TextStyle(
              //     color: Colors.black,
              //     fontSize: 16,
              //     fontWeight: FontWeight.bold,
              //   ),
              // ),
            ],
          ),
        ],
      ),
    );
  }
}

class DashboardGrid extends StatefulWidget {
   final List<CropInformation> cropData;

  DashboardGrid({required this.cropData});
  @override
  _DashboardGridState createState() => _DashboardGridState();
}

class CropInfo {
  var cropName;
  var imagePath;
  var location;
  var price;

  CropInfo({
    required this.imagePath,
    required this.cropName,
    required this.location,
    required this.price,
  });
}

class _DashboardGridState extends State<DashboardGrid> {
  
  final List<String> assetPaths = [
    'assets/fruit1.jpg',
    'assets/fruit2.jpg',
    'assets/fruit3.jpg',
    'assets/fuit4.jpeg',
    'assets/vege1.jpg',
    'assets/vege2.jpeg',
    'assets/vege3.jpeg',
    'assets/rice1.jpeg',
    'assets/dal.jpeg',
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: widget.cropData.length,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.7,
      ),
      itemBuilder: (BuildContext context, int index) {
          CropInformation crop = widget.cropData[index];
           String assetPath = assetPaths[index %
            assetPaths
                .length]; // This will select an asset path iteratively from the assetPaths list.

        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ItemDetails(
                  itemName: crop.name,
                 imagePath: assetPaths[index % assetPaths.length],
                  location: crop.quantity,
                  price: crop.pricePerKg
                ),
              ),
            );
          },
          child: GridTile(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  flex: 3,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      color: Color(0xFF435D0B),
                     
                           child
                          // crop.image.isNotEmpty
                          // ? Image.network(
                          //     crop.image,
                          //     fit: BoxFit.cover,
                          //   )
                          : Image.asset(
                       // assetPaths[1],
                        assetPaths[index % assetPaths.length],
                        fit: BoxFit.cover,
                        width: 60,
                        height: 60,
                      ),
                    ),
                  ),
                ),
               
             Expanded(
                  flex: 1,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          crop.name,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 1), // Adding gap between name and quantity
                        Row(
                          children: [
                            Text(
                              'Quantity: ',
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                            Text(
                              crop.quantity,
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 1), // Adding gap between quantity and price
                        Row(
                          children: [
                            Text(
                              'Price: ₹', // Rupee symbol
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              crop.pricePerKg,
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
             ),
              ],
            ),
            
          ),
        );
      },
    );
  }
}

class BottomBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.067,
      decoration: BoxDecoration(
        color: Color(0xFF435D0B),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 6,
            offset: Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(
            icon: Icon(Icons.person_rounded, color: Colors.white),
            onPressed: () {
              // Implement action for the first icon (person)
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => BuyerDashboard()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.home_filled, color: Colors.white),
            onPressed: () {
              // Navigate to SellerDashboard when home icon is clicked
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => BuyerDashboard()),
              );
            },
          ),
        ],
      ),
    );
  }
}
class CropInformation {
  String name;
  String quantity;
  String pricePerKg;
  String image;

  CropInformation({
    required this.name,
    required this.quantity,
    required this.pricePerKg,
    required this.image
  });

factory CropInformation.fromJson(Map<String, dynamic> json) {
    return CropInformation(
      name: json['name'] ??
          '', // Provide a default empty string if cropName is null
      quantity: json['quantity'] ??
          '', // Provide a default empty string if quantity is null
      pricePerKg: json['pricePerKg'] ??
          '', 
       image: json['image'] ??
          '', // Provide a default empty string if systemDate is null
    );
  }
}