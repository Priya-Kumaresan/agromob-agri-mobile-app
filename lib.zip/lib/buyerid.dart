import 'package:flutter/material.dart';
import 'dart:math';
import 'buyerprofile.dart'; // Import the EditProfilePage

Color darkGreen = Color(0xFF435D0B);

class BuyerIDPage extends StatefulWidget {
  @override
  _BuyerIDPageState createState() => _BuyerIDPageState();
}

class _BuyerIDPageState extends State<BuyerIDPage> {
  final Random _random = Random();
  int _randomNumber = 0;

  void generateRandomNumber() {
    setState(() {
      _randomNumber = 1000 + _random.nextInt(9000);
    });

    // Navigate to the EditProfilePage after generating the random number
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => EditProfilePage(randomNumber: _randomNumber)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffc0e474),
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(0),
        child: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Buyer ID',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              '$_randomNumber',
              style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: generateRandomNumber,
              style: ButtonStyle(
                backgroundColor:
                    MaterialStateProperty.all<Color>(Color(0xFF435D0B)),
              ),
              child: Text(
                'Click to get Buyer ID ',
                style: TextStyle(
                  color: Colors.white, // Text color
                  fontSize: 16, // Text size
                  fontWeight: FontWeight.bold, // Text weight
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
