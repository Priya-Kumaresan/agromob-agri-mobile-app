import 'dart:convert';
import 'dart:io';
import 'package:agromob/services/api3.dart';
import 'sellerdashboard.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'mycrops.dart';

class AddCrop extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Color(0xFFC6EB78), // Theme color C6EB78
      ),
      home: AddCropPage(),
    );
  }
}

class AddCropPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFC6EB78),
              Color(0xFF435D0B),
            ],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.only(top: screenHeight * 0.08),
              child: Center(
                child: Stack(
                  children: [
                    Container(
                      width: screenWidth * 0.29,
                      height: screenWidth * 0.29,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          image: AssetImage('assets/crop.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ), // Adjust the height as needed
            Padding(
              padding: EdgeInsets.only(top: screenHeight * 0.02),
              child: Text(
                'ADD CROP',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black, // Text color
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(screenHeight * 0.02),
              child: TextFields(),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomBar(),
    );
  }
}

class TextFields extends StatefulWidget {
  @override
  _TextFieldsState createState() => _TextFieldsState();
}

class _TextFieldsState extends State<TextFields> {
  var cropNameController = TextEditingController();
  var quantityController = TextEditingController();
  var priceController = TextEditingController();
  List<String> cropTypes = ['Fruits', 'Vegetables', 'Cereals', 'Pulses'];
  String? selectedCropType;
  String? uploadedImage;
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double textFieldWidth = screenWidth * 0.8;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 16.0),
        buildTextField('CROP NAME', textFieldWidth, cropNameController),
        buildTextField('QUANTITY', textFieldWidth, quantityController),
        buildTextField('PRICE PER KG', textFieldWidth, priceController),
        buildDropdownField('TYPE OF CROP', textFieldWidth),
        buildUploadField('PHOTO UPLOAD', textFieldWidth),
        RoundedUploadButton(
          cropName: cropNameController.text,
          quantity: quantityController.text,
          price: priceController.text,
          systemDate: DateTime.now().toString(),
          selectedCropType: selectedCropType,
          uploadedImage: uploadedImage,
        ),
      ],
    );
  }

  Widget buildTextField(
      String hintText, double width, TextEditingController controller) {
    return Container(
      width: width,
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF5E83B9).withOpacity(0.4),
            blurRadius: 3,
            offset: Offset(1, 3),
          ),
        ],
        color: Color(0xFF435D0B),
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 8),
        child: TextField(
          style: TextStyle(
            fontFamily: 'Poppins',
            color: Colors.white,
          ),
          controller: controller,
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }

  Widget buildDropdownField(String hintText, double width) {
    return Builder(
      builder: (context) {
        return Container(
          width: width,
          height: 52,
          margin: EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Color(0xFF5E83B9).withOpacity(0.4),
                blurRadius: 3,
                offset: Offset(1, 3),
              ),
            ],
            color: Color(0xFF435D0B),
          ),
          child: Padding(
            padding: const EdgeInsets.only(left: 8, right: 8),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      selectedCropType ?? hintText,
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        color: selectedCropType == null
                            ? Colors.white.withOpacity(0.7)
                            : Colors.white,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    if (cropTypes.isNotEmpty) {
                      showModalBottomSheet(
                        context: context,
                        builder: (context) => Container(
                          color: Colors.white,
                          height: 200,
                          child: ListView(
                            children: cropTypes.map((crop) {
                              return ListTile(
                                title: Text(crop),
                                onTap: () {
                                  setState(() {
                                    selectedCropType = crop;
                                  });
                                  Navigator.of(context).pop();
                                },
                              );
                            }).toList(),
                          ),
                        ),
                      );
                    }
                  },
                  icon: Icon(
                    Icons.keyboard_arrow_down_rounded,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget buildUploadField(String hintText, double width) {
    return Container(
      width: width,
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF5E83B9).withOpacity(0.4),
            blurRadius: 3,
            offset: Offset(1, 3),
          ),
        ],
        color: Color(0xFF435D0B),
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 8, right: 8),
        child: Row(
          children: [
            Expanded(
              child: TextButton(
                onPressed: () {
                  _getImageFromGallery();
                },
                child: Text(
                  uploadedImage != null ? 'Image Selected' : hintText,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    color: Colors.white.withOpacity(0.7),
                  ),
                ),
              ),
            ),
            IconButton(
              onPressed: () {
                _getImageFromGallery();
              },
              icon: Icon(
                Icons.file_upload_outlined,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _getImageFromGallery() async {
   final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      // Set the uploaded image path
      setState(() {
        uploadedImage = pickedFile.path;
      });
    }
  }
}

class CropInformation {
  var cropName;
  var quantity;
  var systemDate;
  // var uploadedImage;

  CropInformation({
    required this.cropName,
    required this.quantity,
    required this.systemDate,
    // required this.uploadedImage,
  });
}

class BottomBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.067,
      decoration: BoxDecoration(
        color: Color(0xFF435D0B),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 6,
            offset: Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(
            icon: Icon(Icons.person_rounded, color: Colors.white),
            onPressed: () {
              // Implement action for the first icon (person)
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SellerDashboard()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.home_filled, color: Colors.white),
            onPressed: () {
              // Navigate to SellerDashboard when home icon is clicked
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SellerDashboard()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class RoundedUploadButton extends StatelessWidget {
  var cropName;
  var quantity;
  var systemDate;
  var price;
  String? selectedCropType;
  String? uploadedImage;

  RoundedUploadButton({
    required this.cropName,
    required this.quantity,
    required this.price,
    required this.systemDate,
    this.selectedCropType,
    this.uploadedImage,
  });

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      child: Container(
        width: screenWidth * 0.3,
        height: 50,
        margin: EdgeInsets.only(
          top: screenHeight * 0.05,
        ),
        child: ElevatedButton(
          onPressed: () {
            // Validate if all required fields are filled
            if (cropName.isNotEmpty &&
                quantity.isNotEmpty &&
                selectedCropType != null &&
                uploadedImage != null) {
              var data = {
                "name": cropName,
                "quantity": quantity,
                "pricePerKg": price,
                "cropType": selectedCropType,
                "image": uploadedImage
                // Add other fields as needed
              };

              // Pass the data to your API
              // Make sure to replace Api1.addprofile(data) with your actual API call
              Api3.addcrops(data);
              // Create an instance of CropInformation and pass it to MyCrop
              CropInformation cropInfo = CropInformation(
                cropName: cropName,
                quantity: quantity,
                systemDate: systemDate,
              );
              if (cropInfo != null) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MyCrop(
                      systemDate: systemDate,
                    ),
                    //   cropInfo: cropInfo),
                  ),
                );
              }
            }
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF435D0B),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4.0),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'UPLOAD',
                style: TextStyle(
                  fontSize: 12.0,
                  fontFamily: 'Poppins',
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
