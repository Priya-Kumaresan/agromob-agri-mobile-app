class login {
  final String? email;
  final String? password;
  

 login({
    this.email,
    this.password,
    
  });
}
