class signup {
  final String? name;
  final String? email;
  final String? password;
  final String? role;

  signup({this.name, this.email, this.password, this.role});
}
