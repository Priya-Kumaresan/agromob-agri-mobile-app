class orders {
  final String? name;
  final String? price;
  final String? quantity;
  

  orders({
    this.name,
    this.price,
    this.quantity,
  });
}
