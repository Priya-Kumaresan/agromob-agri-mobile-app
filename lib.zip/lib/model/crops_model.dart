class crops {
  final String? name;
  final String? quantity;
  final String? price;
  final String? selectedCropType;
  final String? uploadedImage;
  
  crops({
    this.name,
    this.quantity,
    this.price,
    this.selectedCropType,
    this.uploadedImage,
  });
}

