
class profile {
  final String? name;
  final String? phoneNumber;
  final String? aadharNumber;
  final String? selectedLocation;
  final String? selectedHarvestType;
  final int? randomNumber;

  profile({
    this.name,
    this.phoneNumber,
    this.aadharNumber,
    this.selectedLocation,
    this.selectedHarvestType,
    this.randomNumber,
  });
}
