class details {
  final String? houseName;
  final String? roadName;
  final int? pincode;
  final String? state;
  final String? city;
  final String? name;
  final int? phone;

  details({
    this.houseName,
    this.roadName,
    this.pincode,
    this.state,
    this.city,
    this.name,
    this.phone,
  });
}
