// import 'package:agromob/addcrop.dart';
import 'package:agromob/addcrop.dart';
import 'package:agromob/services/api8.dart';
import 'package:flutter/material.dart';
import 'sellerdashboard.dart';
// import 'sellerprofile.dart';
import 'main.dart';

class MyImageContainer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Container(
      width: screenWidth,
      height: screenHeight * 0.2,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/mycrops.jpeg'),
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}

class MyOrders extends StatefulWidget {
  final CropInformation? cropInfo;
  

  MyOrders({this.cropInfo});

  @override
  _MyOrdersState createState() => _MyOrdersState();
}

class _MyOrdersState extends State<MyOrders> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.transparent, // Theme color C6EB78
      ),
      home: MyOrdersPage(cropInfo: widget.cropInfo
  ),
    );
  }
}

class MyOrdersPage extends StatefulWidget {
  final CropInformation? cropInfo;

MyOrdersPage({this.cropInfo});

  @override
  _MyOrdersPageState createState() => _MyOrdersPageState();
}

class _MyOrdersPageState extends State<MyOrdersPage> {
  bool _isLoading = false;
  List<CropInformation> _cropData = [];
  @override
  void initState() {
    super.initState();
    _fetchCropData();
    // Call your API here or perform any other initialization tasks
  }

  Future<void> _fetchCropData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Call the API to fetch crop data
      dynamic responseData = await Api8.myorders();

      // Convert the dynamic list to a list of CropInformation objects
      List<CropInformation> crops = [];
      for (var cropData in responseData) {
        CropInformation crop = CropInformation.fromJson(cropData);
        crops.add(crop);
      }

      // Update _cropData with fetched data
      setState(() {
        _cropData = crops;
      });
    } catch (e) {
      // Handle any errors that occur during the API call
      print('Error fetching crop data: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFC6EB78),
              Color(0xFF435D0B),
            ],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            MyImageContainer(),
            Padding(
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).size.height * 0.02,
              ),
              child: Text(
                'MY ORDERS',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
            // Expanded(
            //   // Wrap in Expanded to take available space
            //   // child: CropCard(
            //   //   // pickedFile: 'assets/tomato.png',
            //   //   // cropName: cropInfo?.cropName ?? 'Crop 1',
            //   //   // quantity: cropInfo?.quantity ?? '10',
            //   //   // systemDate: cropInfo?.systemDate ?? DateTime.now().toString(),
            //   // ),
            // ),
            _isLoading
                ? CircularProgressIndicator() // Display loading indicator while fetching data
                : Expanded(
                    child: ListView.builder(
                      itemCount: _cropData.length,
                      itemBuilder: (context, index) {
                        // Build a list of CropCard widgets using fetched data
                        return CropCard(
                          // pickedFile: _cropData[index].pickedFile,
                          name: _cropData[index].name,
                          quantity: _cropData[index].quantity,
                          price:_cropData[index].price,
                        );
                      },
                    ),
                  ),
          ],
        ),
      ),
      bottomNavigationBar: BottomBar(),
    );
  }
}

class CropCard extends StatelessWidget {
  // final String pickedFile;
  final String name;
  final String quantity;
 final String  price;

  CropCard({
    // required this.pickedFile,
    required this.name,
    required this.quantity,
     required this.price,
  });

  @override
  Widget build(BuildContext context) {
    double screenheight = MediaQuery.of(context).size.height;
    return SizedBox(
      height: screenheight * 0.2,
      child: Card(
        color: Color(0xFF9EC96D),
        elevation: 3,
        margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        child: Row(
          children: [
            // Expanded(
            //   flex: 1,
            //   child: Container(
            //     height: 100,
            //     width: 100, // Take full height of the Card
            //     child: Image.network(
            //       pickedFile,
            //       fit: BoxFit.cover,
            //     ),
            //   ),
            // ),
            Expanded(
              flex: 3,
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Crop Name: $name',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    SizedBox(height: 4),
                    // Text(
                    //   'Sold On: $systemDate',
                    //   style: TextStyle(
                    //     color: Colors.black,
                    //     fontSize: 14,
                    //   ),
                    // ),
                     Text(
                      'price: $price',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Remaining Stock: $quantity',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class BottomBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.067,
      decoration: BoxDecoration(
        color: Color(0xFF435D0B),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 6,
            offset: Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(
            icon: Icon(Icons.add_box_outlined, color: Colors.white),
            onPressed: () {
              // Navigate to home page or perform any action
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddCropPage()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.home_filled, color: Colors.white),
            onPressed: () {
               Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SellerDashboard()),
              );
              // Navigate to profile page or perform any action
            },
          ),
        ],
      ),
    );
  }
}

class CropInformation {
  String name;
  String quantity;
  String price;

  CropInformation({
    required this.name,
    required this.quantity,
    required this.price,
  });

  // Define a factory method to parse JSON data into CropInformation object
  factory CropInformation.fromJson(Map<String, dynamic> json) {
    return CropInformation(
      name: json['name'] ??
          '', // Provide a default empty string if cropName is null
      quantity: json['quantity'] ??
          '', // Provide a default empty string if quantity is null
      price: json['price'] ??
          '', // Provide a default empty string if systemDate is null
    );
  }
}
