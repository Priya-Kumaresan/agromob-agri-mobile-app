import 'package:agromob/addcrop.dart';
import 'package:agromob/services/api4.dart';
import 'package:flutter/material.dart';

import 'main.dart';

class MyImageContainer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Container(
      width: screenWidth,
      height: screenHeight * 0.2,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/mycrops.jpg'),
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}

class MyCrop extends StatefulWidget {
  final CropInformation? cropInfo;

  MyCrop({this.cropInfo});

  @override
  _MyCropState createState() => _MyCropState();
}

class _MyCropState extends State<MyCrop> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.transparent, // Theme color C6EB78
      ),
      home: MyCropPage(cropInfo: widget.cropInfo),
    );
  }
}

class MyCropPage extends StatefulWidget {
  final CropInformation? cropInfo;

  MyCropPage({this.cropInfo});

  @override
  _MyCropPageState createState() => _MyCropPageState();
}

class _MyCropPageState extends State<MyCropPage> {
  bool _isLoading = false;
  @override
  void initState() {
    super.initState();
    _fetchCropData();
    // Call your API here or perform any other initialization tasks
  }

  Future<void> _fetchCropData() async {
    print("kjrb");
    setState(() {
      _isLoading = true; // Set loading indicator to true while fetching data
    });
    try {
      // Call your backend API here
      // For example, if you want to call the mycrops method from Api4 class:
      await Api4.mycrops();
    } catch (e) {
      // Handle any errors that occur during the API call
      print('Error fetching crop data: $e');
    } finally {
      setState(() {
        _isLoading =
            false; // Set loading indicator to false after fetching data
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFC6EB78),
              Color(0xFF435D0B),
            ],
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            MyImageContainer(),
            Padding(
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).size.height * 0.02,
              ),
              child: Text(
                'MY CROPS',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
            // Expanded(
            //   // Wrap in Expanded to take available space
            //   // child: CropCard(
            //   //   // pickedFile: 'assets/tomato.png',
            //   //   // cropName: cropInfo?.cropName ?? 'Crop 1',
            //   //   // quantity: cropInfo?.quantity ?? '10',
            //   //   // systemDate: cropInfo?.systemDate ?? DateTime.now().toString(),
            //   // ),
            // ),
          ],
        ),
      ),
      bottomNavigationBar: BottomBar(),
    );
  }
}

class CropCard extends StatelessWidget {
  final String pickedFile;
  final String cropName;
  final String quantity;
  final String systemDate;

  CropCard({
    required this.pickedFile,
    required this.cropName,
    required this.quantity,
    required this.systemDate,
  });

  @override
  Widget build(BuildContext context) {
    double screenheight = MediaQuery.of(context).size.height;
    return SizedBox(
      height: screenheight * 0.1,
      child: Card(
        color: Color(0xFF9EC96D),
        elevation: 3,
        margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: Container(
                height: 100,
                width: 100, // Take full height of the Card
                child: Image.network(
                  pickedFile,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Padding(
                padding: EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Crop Name: $cropName',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Sold On: $systemDate',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Remaining Stock: $quantity',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class BottomBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.067,
      decoration: BoxDecoration(
        color: Color(0xFF435D0B),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 6,
            offset: Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(
            icon: Icon(Icons.person_rounded, color: Colors.white),
            onPressed: () {
              // Navigate to home page or perform any action
            },
          ),
          IconButton(
            icon: Icon(Icons.home_filled, color: Colors.white),
            onPressed: () {
              // Navigate to profile page or perform any action
            },
          ),
        ],
      ),
    );
  }
}
