import 'package:flutter/material.dart';

const darkGreen = Color(0xFF435D0B); // Dark green color

List<Color> green = [Color(0xffc0e474), Color(0xff6a7e40)];
