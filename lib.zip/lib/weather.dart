// import 'dart:convert';
// import 'package:http/http.dart' as http;

// class WeatherService {
//   final String apiKey;
//   final String city;

//   WeatherService(this.apiKey, this.city);

//   Future<Map<String, dynamic>> getWeather() async {
//     final response = await http.get(Uri.parse(
//       'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey',
//     ));

//     if (response.statusCode == 200) {
//       return json.decode(response.body);
//     } else {
//       throw Exception('Failed to load weather data');
//     }
//   }
// }

import 'package:flutter/material.dart';

class weather extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: null, // Set the appBar property to null
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                  'weatherr.jpeg'), // Replace 'assets/background_image.jpg' with your image asset path
              fit: BoxFit.cover,
            ),
          ),
          
        ),
      ),
    );
  }
}
