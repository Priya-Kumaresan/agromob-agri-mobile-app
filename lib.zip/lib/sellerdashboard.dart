import 'package:flutter/material.dart';
import 'weather.dart';
import 'addcrop.dart';
import 'mycrops.dart';
import 'sellerprofile.dart';
import 'todo_list.dart';
import 'sellerorder.dart';

const darkGreen = Color(0xFF435D0B);

class SellerDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    int _randomNumber = 0;
    var screenSize = MediaQuery.of(context).size;
    double circleRadius = 30.0; // You can adjust the radius as needed

    return Scaffold(
      body: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xffc0e474), Color(0xff6a7e40)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: Container(
                height: screenSize.height * 0.3,
                decoration: BoxDecoration(
                  color: darkGreen,
                  borderRadius: BorderRadius.circular(circleRadius),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.topLeft,
                        child: Column(
                          children: [
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => EditProfilePage(
                                          randomNumber: _randomNumber)),
                                );
                              },
                              child: CircleAvatar(
                                radius: circleRadius,
                                backgroundColor: Colors.green,
                                child: Icon(
                                  Icons.person,
                                  color: Colors.white,
                                  size: circleRadius * 2,
                                ),
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'PROFILE',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => MyOrders()),
                                );
                              },
                              child: Container(
                                width: circleRadius * 2,
                                height: circleRadius * 2,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage('myorders1.jpeg'),
                                    fit: BoxFit.cover,
                                  ),
                                  borderRadius:
                                      BorderRadius.circular(circleRadius / 2),
                                ),
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'VIEW ORDERS',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => AddCropPage()),
                                );
                              },
                              child: Container(
                                width: circleRadius * 3.7,
                                height: circleRadius * 1.4,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage('myorders.jpeg'),
                                    fit: BoxFit.cover,
                                  ),
                                  borderRadius:
                                      BorderRadius.circular(circleRadius / 2),
                                ),
                                child: Center(
                                  child: Icon(
                                    Icons.add,
                                    color: Colors.white,
                                    size: 30.0,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'ADD NEW CROP',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          MyCrop(systemDate: 'default_date')),
                                );
                              },
                              child: Container(
                                width: circleRadius * 2,
                                height: circleRadius * 2,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage('crops.jpeg'),
                                    fit: BoxFit.cover,
                                  ),
                                  borderRadius:
                                      BorderRadius.circular(circleRadius / 2),
                                ),
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'MY CROPS',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: darkGreen,
                    borderRadius: BorderRadius.circular(circleRadius),
                  ),
                  child: Column(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => TodoListPage()),
                              );
                            },
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(20.0),
                              child: Image.asset(
                                'check.jpeg',
                                fit: BoxFit.cover,
                                width: double.infinity,
                                height: double.infinity,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      weather(), // Navigate to WeatherPage
                                ),
                              );
                            },
                            child: Stack(
                              children: [
                                ClipRRect(
                                  borderRadius:
                                      BorderRadius.circular(circleRadius),
                                  child: Image.asset(
                                    'assets/weather.jpeg',
                                    fit: BoxFit.cover,
                                    width: double.infinity,
                                    height: double.infinity,
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.transparent,
                                    borderRadius:
                                        BorderRadius.circular(circleRadius),
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 20.0),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
