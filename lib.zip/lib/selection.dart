import 'package:flutter/material.dart';
import 'buyersignup.dart';
import 'buyerloginpage.dart';

class SelectionPage extends StatelessWidget {
  const SelectionPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xffc0e474), Color(0xff6a7e40)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Select Login',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 20), // Adjust this value as needed
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => FarmerSignUpPage()),
                  );
                },
                child: Text('Farmer'),
              ),
              SizedBox(height: 10), // Adjust this value as needed
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                  context,
                    MaterialPageRoute(builder: (context) => BuyerLoginPage()),
                  // Functionality for the consumer button goes here
                );
                },
                child: Text('Consumer'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
