import 'package:agromob/sellerdashboard.dart';
import 'package:agromob/services/auth_service.dart';
import 'package:flutter/material.dart';
import 'selection.dart';
// import 'buyersignup.dart';
// import 'sellerprofile.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Use a Future.delayed to navigate to the SelectionPage after 3 seconds
    // Future.delayed(const Duration(seconds: 3), () {
    //   Navigator.pushReplacement(
    //     context,
    //     MaterialPageRoute(builder: (context) => const SelectionPage()),
    //   );
    Future.delayed(const Duration(seconds: 3), () async {
      final token = await AuthService().getToken();
      if (token == null) {
        // Token exists, navigate to SelectionPage
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const SelectionPage()),
        );
      } else {
        // Token does not exist, navigate to LandingPage
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => SellerDashboard()),
        );
      }
    });

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xffc0e474), Color(0xff6a7e40)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child:
              Image.asset('assets/image-3.png'), // Add your splash image asset
        ),
      ),
    );
  }
}
