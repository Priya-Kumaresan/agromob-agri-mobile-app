import 'package:agromob/services/auth_service.dart';

import 'sellerdashboard.dart';
import 'sellerid.dart';
import 'package:flutter/material.dart';
import 'package:agromob/services/api1.dart';
import 'selection.dart';

Color darkGreen = Color(0xFF435D0B);

class EditProfilePage extends StatefulWidget {
  int randomNumber;

  EditProfilePage({Key? key, required this.randomNumber}) : super(key: key);
  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  String? _selectedLocation;
  String? _selectedHarvestType;

  List<String> _locations = [
    'Andhra Pradesh',
    'Arunachal Pradesh',
    'Assam',
    'Bihar',
    'Chhattisgarh',
    'Goa',
    'Gujarat',
    'Haryana',
    'Himachal Pradesh',
    'Jammu and Kashmir',
    'Jharkhand',
    'Karnataka',
    'Kerala',
    'Madhya Pradesh',
    'Maharashtra',
    'Manipur',
    'Meghalaya',
    'Mizoram',
    'Nagaland',
    'Orissa',
    'Punjab',
    'Rajasthan',
    'Sikkim',
    'Tamil Nadu',
    'Tripura',
    'Uttarakhand',
    'Uttar Pradesh',
    'West Bengal',
    ''
  ]; // Example locations
  List<String> _harvestTypes = [
    'Type A',
    'Type B',
    'Type C'
  ]; // Example harvest types

  var _formKey = GlobalKey<FormState>(); // Key for the form

  var nameController = TextEditingController();
  var phoneNumberController = TextEditingController();
  var aadharNumberController = TextEditingController();

  @override
  void dispose() {
    nameController.dispose();
    phoneNumberController.dispose();
    aadharNumberController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('EDIT PROFILE'),
        backgroundColor: Color(0xFF435D0B), // Set your desired app bar color
        actions: [
          IconButton(
            icon: Icon(Icons.logout, color: Colors.black),
            onPressed: () async {
              // Call removeToken to clear the token
              await AuthService().removeToken();

              // Navigate to the selection page
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => SelectionPage()),
              );
            },
          ),
        ],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => SellerDashboard()),
            );
          },
        ),
      ),

      resizeToAvoidBottomInset:
          true, // Ensure the keyboard does not resize the view
      body: Padding(
        padding: const EdgeInsets.only(top: 0.0),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xffc0e474), Color(0xff6a7e40)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: EdgeInsets.all(30), // Add padding to the container
            child: SingleChildScrollView(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SizedBox(height: 20),
                    Padding(
                      padding: const EdgeInsets.only(left: 2.0),
                      child: Text(
                        'Seller ID: ${widget.randomNumber}',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    SizedBox(height: 12),
                    Form(
                      key: _formKey, // Assign the form key
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          SizedBox(height: 20),
                          TextFormField(
                            controller: nameController,
                            decoration: InputDecoration(
                              labelText: 'Name',
                              border: OutlineInputBorder(),
                              labelStyle: TextStyle(
                                  color: Colors.black), // Change label color
                            ),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your name';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 12),
                          TextFormField(
                            controller: phoneNumberController,
                            decoration: InputDecoration(
                              labelText: 'Phone Number',
                              border: OutlineInputBorder(),
                              labelStyle: TextStyle(
                                  color: Colors.black), // Change label color
                            ),
                            keyboardType: TextInputType.phone,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your phone number';
                              } else if (value.length != 10) {
                                return 'Phone number must be 10 digits long';
                              }
                              // You can add more complex phone number validation here if needed
                              return null;
                            },
                          ),
                          SizedBox(height: 12),
                          TextFormField(
                            controller: aadharNumberController,
                            decoration: InputDecoration(
                              labelText: 'Aadhar Number',
                              border: OutlineInputBorder(),
                              labelStyle: TextStyle(
                                  color: Colors.black), // Change label color
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your Aadhar number';
                              } else if (value.length != 12) {
                                return 'Aadhar number must be 12 digits long';
                              }
                              // You can add more complex Aadhar number validation here if needed
                              return null;
                            },
                          ),
                          SizedBox(height: 12),
                          DropdownButtonFormField<String>(
                            decoration: InputDecoration(
                              labelText: 'Location',
                              border: OutlineInputBorder(),
                              labelStyle: TextStyle(
                                  color: Colors.black), // Change label color
                            ),
                            value: _selectedLocation,
                            onChanged: (String? newValue) {
                              setState(() {
                                _selectedLocation = newValue;
                              });
                            },
                            items: _locations
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please select your location';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 12),
                          DropdownButtonFormField<String>(
                            decoration: InputDecoration(
                              labelText: 'Type of Harvest',
                              border: OutlineInputBorder(),
                              labelStyle: TextStyle(
                                  color: Colors.black), // Change label color
                            ),
                            value: _selectedHarvestType,
                            onChanged: (String? newValue) {
                              setState(() {
                                _selectedHarvestType = newValue;
                              });
                            },
                            items: _harvestTypes
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please select the type of harvest';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: 20),
                          SizedBox(height: 160),
                          ElevatedButton(
                            onPressed: () {
                              // Validate the form before saving
                              if (_formKey.currentState!.validate()) {
                                var data = {
                                  "name": nameController.text,
                                  "phoneNumber": phoneNumberController.text,
                                  "aadharNumber": aadharNumberController.text,
                                  "selectedLocation": _selectedLocation,
                                  "selectedHarvestType": _selectedHarvestType,
                                  "randomNumber": widget.randomNumber.toString()
                                };
                                Api1.addprofile(data);
                                // Form is valid, proceed with saving
                                // Add your update profile logic here

                                // Navigate to the SellerDashboardPage
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => SellerDashboard()),
                                );
                              }
                            },
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: 16.0), // Add vertical padding
                              child: Text('Save'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ]),
            ),
          ),
        ),
      ),
    );
  }
}
