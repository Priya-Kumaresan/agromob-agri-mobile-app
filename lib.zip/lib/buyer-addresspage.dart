import 'newaddresspage.dart';
import 'package:flutter/material.dart';
import 'package:agromob/services/api5.dart';

Color darkGreen = Color(0xFF435D0B);

class BuyerAddressPage extends StatefulWidget {
  @override
  _BuyerAddressPageState createState() => _BuyerAddressPageState();
}

class _BuyerAddressPageState extends State<BuyerAddressPage> {
  TextEditingController houseNameController = TextEditingController();
  TextEditingController roadNameController = TextEditingController();
  TextEditingController pincodeController = TextEditingController();
  TextEditingController stateController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  TextEditingController nameController =
      TextEditingController(); // Controller for name field
  TextEditingController phoneController =
      TextEditingController(); // Controller for phone field

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  void _submitAddress(BuildContext context) {
    if (_formKey.currentState?.validate() ?? false) {
      // Get the entered values
      var data={
        "houseName":houseNameController.text,
      "roadName" : roadNameController.text,
  "pincode":pincodeController.text,
      "state" : stateController.text,
      "city" : cityController.text,
      "name" : nameController.text,
      "phone" : phoneController.text,
      
      };
      // Navigate to the AddBuyerAddressPage and pass the data
    Api5.adddetails(data);
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => AddBuyerAddressPage(
           houseName: houseNameController.text,
            roadName: roadNameController.text,
            pincode: pincodeController.text,
            state: stateController.text,
            city: cityController.text,
            name: nameController.text,
            phone: phoneController.text,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ADD DELIVERY ADDRESS'),
        backgroundColor: darkGreen,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ListView(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: Icon(
                            Icons.location_on,
                            size: 40,
                            color: darkGreen,
                          ),
                        ),
                        Text(
                          'Address',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: darkGreen,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    TextFormField(
                      controller: houseNameController,
                      decoration: InputDecoration(
                        hintText: 'House/Building Name',
                      ),
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'Please enter House/Building Name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      controller: roadNameController,
                      decoration: InputDecoration(
                        hintText: 'Road Name/Area/Colony',
                      ),
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'Please enter Road Name/Area/Colony';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      controller: pincodeController,
                      decoration: InputDecoration(
                        hintText: 'Pin Code',
                      ),
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'Please enter Pin Code';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: stateController,
                            decoration: InputDecoration(
                              hintText: 'State',
                            ),
                            validator: (value) {
                              if (value?.isEmpty ?? true) {
                                return 'Please enter State';
                              }
                              return null;
                            },
                          ),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: cityController,
                            decoration: InputDecoration(
                              hintText: 'City',
                            ),
                            validator: (value) {
                              if (value?.isEmpty ?? true) {
                                return 'Please enter City';
                              }
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 30),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Icon(Icons.phone, size: 40, color: darkGreen),
                        SizedBox(width: 10),
                        Text(
                          'Contact Details',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: darkGreen,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    TextFormField(
                      controller: nameController, // Assign the name controller
                      decoration: InputDecoration(
                        hintText: 'Name',
                      ),
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'Please enter Name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      controller:
                          phoneController, // Assign the phone controller
                      decoration: InputDecoration(
                        hintText: 'Phone',
                      ),
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'Please enter Phone';
                        }
                        return null;
                      },
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  // Handle button tap
                  _submitAddress(context); // Call function to submit address
                },
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(vertical: 15),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: darkGreen,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    'Save this address and continue',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
