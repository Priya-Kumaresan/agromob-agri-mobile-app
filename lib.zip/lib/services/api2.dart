import 'dart:convert';
import 'package:agromob/services/auth_service.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Api {
  static const baseUrl = "http://localhost:3000/auth/login";
  static addlogin(Map pdata) async {
    print(pdata);
    var url = Uri.parse(baseUrl);
    print(url);
    try {
      var res = await http.post(url, body: pdata);
      final AuthService _authService = AuthService();
      print(res);
      if (res.statusCode == 201) {
        var data = jsonDecode(res.body.toString());
        _authService.saveToken(data['token']);
        // Map<String, dynamic> token = await _authService.getDecodedToken();
        // print("Tommy token ${token}");
        return res;
      } else {
        print(res.body);
        print("Failed to get response");
      }
    } catch (e) {
      print("Failed to get response catch in api2");
      debugPrint(e.toString());
    }
  }
}
