import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

class Api5 {
  static const baseUrl = "http://localhost:3000/details";
  static adddetails(Map pdata) async {
    print(pdata);
    var url = Uri.parse(baseUrl);
    try {
      print("HEllo");
      var res = await http.post(url, body: pdata);
      print(res);
      if (res.statusCode == 200) {
        var data = jsonDecode(res.body.toString());
        print(data);
      } else {
        print("Failed to get response");
      }
    } catch (e) {
      debugPrint(e.toString());
    }
  }
}
