import 'dart:convert';
import 'package:agromob/services/auth_service.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

class Api8 {
  static const baseUrl = "http://localhost:3000/orders";
  static myorders() async {
    var url = Uri.parse('$baseUrl');
    print("url=================,${url}");
    try {
      var res = await http.get(url);
      print(res);
      if (res?.body != null) {
        var data = jsonDecode(res.body.toString());
        print(data);
        return data;
      } else {
        print("Failed to get response");
      }
    } catch (e) {
      print("Failed to get response catch in mycrop");
      debugPrint(e.toString());
    }
  }
}
