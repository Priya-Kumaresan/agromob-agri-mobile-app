import 'dart:convert';
import 'package:agromob/services/auth_service.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

class Api4 {
  static const baseUrl = "http://localhost:3000/crops";
  static mycrops() async {
    final AuthService _authService = AuthService();
    Map<String, dynamic>? token = await _authService.getDecodedToken();
    var url = Uri.parse('$baseUrl/${token?['email']}');
    print("url=================,${url}");
    try {
      var res = await http.get(url);
      print(res);
      if (res?.body != null) {
        var data = jsonDecode(res.body.toString());
        //print(data);
        return data;
      } else {
        print("Failed to get response");
      }
    } catch (e) {
      print("Failed to get response catch in mycrop");
      debugPrint(e.toString());
    }
  }
}
