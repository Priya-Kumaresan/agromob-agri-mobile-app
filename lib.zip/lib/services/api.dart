import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

class Api {
  static const baseUrl = "http://localhost:3000/auth/signup";
  static adduser(Map pdata) async {
    print(pdata);
    var url = Uri.parse(baseUrl);
    print(url);
    try {
      // print("hello");
      var res = await http.post(url, body: pdata);
      print(res.statusCode); // Log the response status code
      // print(res.statusCode == 201); // Log the response status code
      // print(res.body); // Log the response body
      if (res.statusCode == 201) {
        var data = jsonDecode(res.body.toString());
        print(data);
        return res;
      } else {
        print("Failed to get response");
      }
    } catch (e) {
      print("Failed to get response catch in api.dart");
      debugPrint(e.toString());
    }
  }
}
