// import 'dart:convert';

// import 'package:shared_preferences/shared_preferences.dart';

// class AuthService {
//   Future<void> saveToken(String token) async {
//     final prefs = await SharedPreferences.getInstance();
//     prefs.setString('token', token);
//   }

//   Future<String?> getToken() async {
//     final prefs = await SharedPreferences.getInstance();
//     return prefs.getString('token');
//   }

//   Future<Map<String, dynamic>> getDecodedToken() async {
//     final prefs = await SharedPreferences.getInstance();
//     final token = prefs.getString('token');
//     final parts = token?.split('.');
//     if (parts?.length != 3) {
//       throw Exception('Invalid token');
//     }
//     final payload = parts?[1];
//     final String decodedPayload = utf8.decode(base64Url.decode(payload!));
//     final Map<String, dynamic> decodedMap = json.decode(decodedPayload);
//     return decodedMap;
//   }
// }

import 'dart:convert';

import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  String? _token;

  // Getter for the token
  String? get token => _token;

  // Initialize AuthService by loading token from SharedPreferences
  AuthService() {
    getToken();
  }

  // Save token to SharedPreferences and update in-memory token
  Future<String?> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
    _token = token;
    return _token;
  }

  // Load token from SharedPreferences
  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('token');
    return _token;
  }

  // Remove token from SharedPreferences and clear in-memory token
  Future<String?> removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    _token = null;
    return _token;
  }

  Future<Map<String, dynamic>?> getDecodedToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    if (token != null) {
      try {
        Map<String, dynamic> decodedToken = JwtDecoder.decode(token!);
        return decodedToken;
      } catch (e) {
        print('Error decoding token: $e');
        return null;
      }
    } else {
      print('Token is null.');
      return null;
    }
  }
  // Decode token payload
  // Future<Map<String, dynamic>> getDecodedToken() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   final token = prefs.getString('token');
  //   if (token == null) {
  //     throw Exception('Token not available');
  //   }
  //   final parts = token?.split('.');
  //   if (parts?.length != 3) {
  //     throw Exception('Invalid token');
  //   }
  //   final payload = parts?[1];
  //   final String decodedPayload = utf8.decode(base64.decode(payload!));
  //   final Map<String, dynamic> decodedMap = json.decode(decodedPayload);
  //   return decodedMap;
  // }
  // Future<Map<String, dynamic>> getDecodedToken() async {
  //   // Ensure token is loaded before attempting to decode
  //   final prefs = await SharedPreferences.getInstance();
  //   _token = prefs.getString('token');
  //   if (_token == null) {
  //     throw Exception('Token not available');
  //   }

  //   final parts = _token!.split('.');
  //   if (parts.length != 3) {
  //     throw Exception('Invalid token');
  //   }

  //   final payload = parts[1];
  //   final String decodedPayload = utf8.decode(base64Url.decode(payload));
  //   final Map<String, dynamic> decodedMap = json.decode(decodedPayload);
  //   return decodedMap;
  // }
}
