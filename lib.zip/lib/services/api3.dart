import 'dart:convert';
import 'package:agromob/services/auth_service.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';

class Api3 {
  static const baseUrl = "http://localhost:3000/crops";

  static addcrops(Map pdata) async {
    final AuthService _authService = AuthService();
    Map<String, dynamic>? token = await _authService.getDecodedToken();
    var url = Uri.parse(baseUrl);
    pdata['email'] = token?['email'];
    try {
      print("HEllo");
      var res = await http.post(url, body: pdata);
      print("crops ==> ${res.statusCode}");
      if (res.statusCode == 201) {
        var data = jsonDecode(res.body.toString());
        print(data);
      } else {
        print("Failed to get response in add crops");
      }
    } catch (e) {
      debugPrint(e.toString());
    }
  }
}
