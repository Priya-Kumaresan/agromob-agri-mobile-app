import 'package:flutter/material.dart';
import 'package:twilio_flutter/twilio_flutter.dart';
import 'buyerdashboard.dart';
import 'buyerprofile.dart';

class OrderConfirmationPage extends StatelessWidget {
  final TwilioFlutter twilioFlutter = TwilioFlutter(
    accountSid: 'AC84852ead1ca007307af34fee17878496',
    authToken: '94b965145ac1dc0b2bb23cd9932ecd7b',
    twilioNumber: '+12566023077',
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Order Confirmation',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor:
            Colors.transparent, // Make the app bar background transparent
        elevation: 0, // Remove app bar shadow
        automaticallyImplyLeading: false,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
               Color(0xffc0e474),
                 Color(0xff6a7e40)
              ], // Dark green gradient
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          color: Color(0xffc0e474), // Set light green color for the body
        ),
        child: Center(
          child: Container(
            width: 200, // Adjust the width as needed
            height: 50, // Adjust the height as needed
            child: ElevatedButton(
              onPressed: () {
                _sendOrderConfirmationSMS();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xff6a7e40),// Set button background color to dark green
                shadowColor: Colors.transparent, // Remove button shadow
              ),
              child: Text(
                'Send Order Confirmation SMS',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor:  Color(0xff6a7e40), // Set bottom navigation bar background color to dark green
        elevation: 0, // Remove bottom navigation bar shadow
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home,
                color: Colors.white), // Set icon color to white
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person,
                color: Colors.white), // Set icon color to white
            label: 'Profile',
          ),
        ],
        selectedItemColor: Colors.white, // Set selected item color to white
        unselectedItemColor: Colors.white.withOpacity(
            0.5), // Set unselected item color to white with 50% opacity
        onTap: (int index) {
          if (index == 0) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => BuyerDashboard()),
            );
          } else if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => EditProfilePage(randomNumber: 0)),
            );
          }
        },
      ),
    );
  }

  void _sendOrderConfirmationSMS() async {
    try {
      await twilioFlutter.sendSMS(
        toNumber: '+917358884720',
        messageBody: 'We extend our heartfelt gratitude for using AgroMob\n'
            'Your order has been confirmed. Thank you!',
      );
      print('SMS sent successfully');
    } catch (e) {
      print('Failed to send SMS: $e');
    }
  }
}
