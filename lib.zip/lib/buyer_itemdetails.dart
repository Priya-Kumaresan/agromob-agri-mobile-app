import 'package:flutter/material.dart';
//import 'package:sample/main.dart';
import 'buyerdashboard.dart';
import 'buyer-addresspage.dart';
import 'package:agromob/services/api7.dart';

class ItemDetails extends StatefulWidget {
  var itemName;
  var location;
  var price;
  var imagePath;

  ItemDetails({
    required this.itemName,
    required this.location,
    required this.price, 
    required this. imagePath,
  });
    @override
  _ItemDetailsState createState() => _ItemDetailsState();
}
class _ItemDetailsState extends State<ItemDetails> {
  final _formKey=GlobalKey<FormState>();
  late String quantity='';
  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        title: Text('Item Details: ${widget.itemName}'),
        backgroundColor: Color(0xFF435D0B),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFC4E977),
              Color(0xFF6E8343),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                height: screenSize.height * 0.5,
                decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(widget.imagePath),
                      fit: BoxFit.cover,
                    ),
                    ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Details of ${widget.itemName}',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 20),
                    // Text(
                    //   'Price: $price',
                    //   style: TextStyle(fontSize: 20),
                    // ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Price:',
                          style: TextStyle(fontSize: 20),
                        ),
                        SizedBox(width: 10), 
                        Text(
                          '${widget.price}',
                          style: TextStyle(fontSize: 20),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    Form(
                      key: _formKey,
                      child:TextFormField(
                     onChanged: (value) {
                          setState(() {
                            quantity = value;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter quantity';
                          }
                          return null;
                        },
                      decoration: InputDecoration(
                        hintText: 'Enter quantity',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    ),
                    SizedBox(height: 20),
                    // Individual Buttons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton.icon(
                           onPressed: ()  {
            if (_formKey.currentState!.validate()) {
              var data = {
                "name": widget.itemName,
                "price": widget.price,
                "quantity": quantity,
              };
             Api7.orders(data);
              Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => BuyerAddressPage()),
                            );
            }
         },
                          icon: Icon(Icons.shopping_bag),
                          label: Text(
                            'Buy Now',
                            style: TextStyle(fontSize: 17),
                          ),
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(
                                Color(0xFF435D0B)), // Button color
                            foregroundColor: MaterialStateProperty.all(
                                Colors.white), // Text color
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                            ),
                            minimumSize: MaterialStateProperty.all(
                                Size(120, 70)), // Button size
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomBar(),
    );
  }
 
}





