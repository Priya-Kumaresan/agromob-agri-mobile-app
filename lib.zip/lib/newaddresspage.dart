import 'buyer-addresspage.dart';
import 'buyerprofile.dart';
import 'package:flutter/material.dart';
import 'authenticate.dart';

Color darkGreen = Color(0xFF435D0B);

class AddBuyerAddressPage extends StatelessWidget {
  String houseName;
  String roadName;
  String pincode;
  String state;
  String city;
  String name;
  String phone;

  AddBuyerAddressPage({
    required this.houseName,
    required this.roadName,
    required this.pincode,
    required this.state,
    required this.city,
    required this.name,
    required this.phone,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        BuyerAddressPage(), // Navigate to BuyerAddressPage
                  ),
                );
              },
              child: Icon(Icons.add),
            ),
            SizedBox(width: 8),
            Text('Add New Address'),
          ],
        ),
        backgroundColor: darkGreen,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'House/Building Name: $houseName',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              'Road Name/Area/Colony: $roadName',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              'Pin Code: $pincode',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              'State: $state',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              'City: $city',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            Text(
              'Name: $name',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              'Phone: $phone',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                 Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                          OrderConfirmationPage(), // Provide a value for randomNumber
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: darkGreen,
                padding: EdgeInsets.symmetric(vertical: 16, horizontal: 32),
              ),
              child: Text(
                'Deliver to this address',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
        ],
        onTap: (int index) {
          if (index == 0) {
            // Navigate to BuyerProfilePage
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => EditProfilePage(
                    randomNumber: 0), // Provide a value for randomNumber
              ),
            );
          }
        },
      ),
    );
  }
}
