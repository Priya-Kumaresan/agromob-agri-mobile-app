import 'dart:convert';
import 'sellerdashboard.dart';
import 'package:flutter/material.dart';
import 'add_page.dart';
// Import SellerDashboard page
import 'package:http/http.dart' as http;

class TodoListPage extends StatefulWidget {
  const TodoListPage({Key? key}) : super(key: key);

  @override
  State<TodoListPage> createState() => _TodoListPageState();
}

class _TodoListPageState extends State<TodoListPage> {
  bool isLoading = true;
  List items = [];
  TextEditingController searchController = TextEditingController();
  ThemeMode _currentThemeMode = ThemeMode.light; // Default to light mode

  @override
  void initState() {
    super.initState();
    fetchTodo();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Todo List',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Color(0xFF367366),
        actions: [
          IconButton(
            icon: Icon(Icons.lightbulb_outline),
            onPressed: toggleTheme,
          ),
        ],
      ),
      backgroundColor: Color(0xFF121212),
      body: Theme(
        data: ThemeData.dark(),
        child: Visibility(
          visible: isLoading,
          child: Center(
            child: CircularProgressIndicator(
              color: Color(0xFF367366),
            ),
          ),
          replacement: RefreshIndicator(
            onRefresh: fetchTodo,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    controller: searchController,
                    decoration: InputDecoration(
                      labelText: 'Search',
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Color(0xFF367366)),
                      ),
                      labelStyle: TextStyle(color: Colors.grey),
                    ),
                    onChanged: (value) {
                      filterTasks(value);
                    },
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: items.length,
                    itemBuilder: (context, index) {
                      final item = items[index] as Map<String, dynamic>;
                      final id = item['_id'] as String;
                      final progress = item['progress'] as double?;

                      return Card(
                        elevation: 4,
                        margin:
                            EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                        child: ListTile(
                          leading: CircleAvatar(
                            child: Text(
                              '${index + 1}',
                              style: TextStyle(color: Colors.white),
                            ),
                            backgroundColor: Color(0xFF367366),
                          ),
                          title: Text(
                            item['title'].toString(),
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(item['description'].toString()),
                              SizedBox(height: 8),
                              if (progress != null)
                                LinearProgressIndicator(
                                  value: progress,
                                  backgroundColor: Colors.grey[300],
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.blue),
                                ),
                            ],
                          ),
                          trailing: PopupMenuButton(
                            icon: Icon(Icons.more_vert),
                            onSelected: (value) {
                              if (value == 'edit') {
                                navigateToEditPage(item);
                              } else if (value == 'delete') {
                                deleteById(id);
                              }
                            },
                            itemBuilder: (context) {
                              return [
                                PopupMenuItem(
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.edit,
                                        color: Colors.blue,
                                      ),
                                      SizedBox(width: 8),
                                      Text(
                                        'Edit',
                                        style: TextStyle(color: Colors.blue),
                                      ),
                                    ],
                                  ),
                                  value: 'edit',
                                ),
                                PopupMenuItem(
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.delete,
                                        color: Colors.red,
                                      ),
                                      SizedBox(width: 8),
                                      Text(
                                        'Delete',
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    ],
                                  ),
                                  value: 'delete',
                                ),
                              ];
                            },
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: navigateToAddPage,
        label: Text('Add Todo'),
        backgroundColor: Color(0xFF367366),
        icon: Icon(Icons.add),
      ),
    );
  }

  Future<void> navigateToEditPage(Map<String, dynamic> item) async {
    final route = MaterialPageRoute(
      builder: (context) => AddTodoPage(todo: item),
    );
    await _navigateAndReload(route);
  }

  Future<void> navigateToAddPage() async {
    final route = MaterialPageRoute(
      builder: (context) => AddTodoPage(),
    );
    await _navigateAndReload(route);
  }

  Future<void> _navigateAndReload(MaterialPageRoute route) async {
    await Navigator.push(context, route);
    setState(() {
      isLoading = true;
    });
    fetchTodo();
  }

  Future<void> deleteById(String id) async {
    final url = 'https://api.nstack.in/v1/todos/$id';
    final uri = Uri.parse(url);

    final response = await http.delete(uri);

    if (response.statusCode == 200) {
      final filtered = items.where((element) => element['_id'] != id).toList();
      setState(() {
        items = filtered;
      });
    } else {
      showErrorMessage('Deletion Failed');
    }
  }

  Future<void> fetchTodo() async {
    final url = "https://api.nstack.in/v1/todos?page=1&limit=10";
    final uri = Uri.parse(url);
    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body) as Map<String, dynamic>;
      final result = json['items'] as List;
      setState(() {
        items = result;
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
      showErrorMessage('Failed to fetch Todos');
    }
  }

  void showErrorMessage(String message) {
    final snackBar = SnackBar(
      content: Text(
        message,
        style: TextStyle(color: Colors.white),
      ),
      backgroundColor: Colors.red,
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  void filterTasks(String query) {
    if (query.isNotEmpty) {
      List filteredList = [];
      items.forEach((item) {
        if (item['title']
            .toString()
            .toLowerCase()
            .contains(query.toLowerCase())) {
          filteredList.add(item);
        }
      });
      setState(() {
        items = filteredList;
      });

      if (filteredList.isEmpty) {
        // Display alert box if no matches found
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text("No Matches Found"),
              content: Text("No tasks match your search query."),
              actions: <Widget>[
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text("OK"),
                ),
              ],
            );
          },
        );
      }
    } else {
      fetchTodo();
    }
  }

  void toggleTheme() {
    setState(() {
      if (_currentThemeMode == ThemeMode.light) {
        _currentThemeMode = ThemeMode.dark;
      } else {
        _currentThemeMode = ThemeMode.light;
      }
    });
  }
}
