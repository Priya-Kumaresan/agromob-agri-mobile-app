import 'package:agromob/services/auth_service.dart';
import 'package:flutter/material.dart';
// import 'buyerprofile.dart';
 import 'buyersignuppage.dart';
// Import your EditProfilePage file here
import 'package:agromob/services/api2.dart';
import 'buyerdashboard.dart';

Color darkGreen = Color(0xFF435D0B);

class BuyerLoginPage extends StatefulWidget {
  @override
  _BuyerLoginPageState createState() => _BuyerLoginPageState();
}

class _BuyerLoginPageState extends State<BuyerLoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  static const String role = 'consumer';

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xffc0e474), Color(0xff6a7e40)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child:Form(
          key:_formKey,
        
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 30),
                    Center(
                      child: Image.asset(
                        'assets/image-3.png', // Replace with your image asset path
                        fit: BoxFit.cover,
                      ),
                    ),
                    SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Text(
                        'Login',
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: TextField(
                        controller: _emailController,
                        decoration: InputDecoration(
                          labelText: 'Email',
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: TextField(
                        controller: _passwordController,
                        obscureText: true,
                        decoration: InputDecoration(
                          labelText: 'Password',
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 80),
              child: Column(
                children: [
                  SizedBox(
                    width: 150, // Adjust the width as needed
                    height: 50, // Adjust the height as needed
                    child: ElevatedButton(
                      onPressed: () async {
                        
                        // Perform your login logic here
                        // For demonstration purposes, navigate to the BuyerProfilePage
                        if (_formKey.currentState!.validate()) {
                          // Form is valid, perform login logic
                          var data = {
                            "email": _emailController.text,
                            "password": _passwordController.text,
                            "role": role
                          };
                          var res = await Api.addlogin(data);
                          print("res container");
                          print(res);
                          print(res.statusCode == 201);
                          final token =await AuthService().getToken();
                        //   // Call your login API here
                          if (res.statusCode == 201) {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => BuyerDashboard()),
                              //builder: (context) => AddCropPage()),
                            );
                          } else {
                            // Show alert dialog to indicate login failure
                            showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: Text('Login Failed'),
                                content:
                                    Text('Email and password do not match'),
                                actions: <Widget>[
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Text('OK'),
                                  ),
                                ],
                              ),
                            );
                          }
                        }

                      },
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(darkGreen),
                      ),
                      child: Text(
                        'Login',
                        style: TextStyle(
                          fontSize: 18, // Adjust the font size as needed
                          fontWeight: FontWeight.bold,
                          color: Colors.white, // Adjust the text color as needed
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  TextButton(
                    onPressed: () {
                      // Navigate to the sign-up page
                      Navigator.pop(context); // Close the current login page
                     Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => BuyerSignUpPage()),
                      );
                    },
                    child: Text(
                      'Don\'t have an account? Sign up',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      ),
    );
  }
}
