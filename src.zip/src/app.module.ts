import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MongooseModule } from '@nestjs/mongoose';
import { ProfileModule } from './profile/profile.module';
import { CropsModule } from './crops/crops.module';
import { AuthModule } from './auth/auth.module';
//import { Auth1Module } from './auth1/auth1.module';
// import { BuyerprofileModule } from './buyerprofile/buyerprofile.module';
// import { DetailsController } from './details/details.controller';
// import { DetailsService } from './details/details.service';
import { DetailsModule } from './details/details.module';
import { OrdersModule } from './orders/orders.module';

@Module({
  imports: [
    MongooseModule.forRoot('mongodb://127.0.0.1/agromob'),
    ProfileModule,
    AuthModule,
    CropsModule,
    DetailsModule,
    OrdersModule,
    // BuyerprofileModule,
    //Auth1Module,
  ],
  // controllers: [AppController, DetailsController],
  // providers: [AppService, DetailsService],
})
export class AppModule {}
