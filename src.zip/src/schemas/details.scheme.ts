import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { User } from './user.scheme';
import mongoose from 'mongoose';

@Schema({
  timestamps: true,
})
export class Details {
  @Prop({ require: true })
  houseName: string;

  @Prop({ require: true })
  roadName: string;

  @Prop({ require: true })
  pincode: number;

  @Prop({ require: true })
  state: string;

  @Prop({ require: true })
  city: string;

  @Prop({ require: true })
  name: string;

  @Prop({ require: true })
  phone: number;

}

export const DetailsSchema = SchemaFactory.createForClass(Details);
