import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { User } from './user.scheme';
import mongoose from 'mongoose';

@Schema({
  timestamps: true,
})
export class Orders {
  @Prop({ require: true })
  name: string;

  @Prop({ require: true })
  price: string;

  @Prop({ require: true })
  quantity: string;


  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'User' })
  user: User;
}

export const OrdersSchema = SchemaFactory.createForClass(Orders);
