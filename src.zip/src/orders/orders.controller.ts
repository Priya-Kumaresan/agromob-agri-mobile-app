import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import mongoose from 'mongoose';
import { OrdersService } from './orders.service';
import { CreateOrdersDto } from './dto/createOrders.dto';
// import { AuthGuard } from '@nestjs/passport';
// import { Profile } from 'src/schemas/profile.scheme';

@Controller('orders')
export class OrdersController {
  constructor(private ordersService: OrdersService) {}

  @Post()
  //  @UseGuards(AuthGuard())
  // async
  createOrders(@Body() createOrdersDto: CreateOrdersDto) {
    //,@Req() req):Promise<Profile> {
    console.log(createOrdersDto);
    return this.ordersService.createOrders(createOrdersDto);
    //,req.user);
  }
  @Get()
  getOrders() {
    return this.ordersService.getOrders();
  }
}