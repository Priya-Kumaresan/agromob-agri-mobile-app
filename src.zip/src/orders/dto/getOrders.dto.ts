import { IsNotEmpty, IsInt, IsString, IsEmail } from 'class-validator';
import { isFloat64Array } from 'util/types';

export class GetOrdersDto {
 
}
