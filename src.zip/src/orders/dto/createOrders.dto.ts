import { IsNotEmpty, IsString, IsNumber, IsEmpty } from 'class-validator';
//import { User } from "src/schemas/user.scheme";

export class CreateOrdersDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  price: string;

  @IsNotEmpty()
  @IsString()
  quantity: string;


}
