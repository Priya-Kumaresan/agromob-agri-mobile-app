import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
import { Orders } from 'src/schemas/orders.scheme';
// import { User } from 'src/schemas/user.scheme';
import { CreateOrdersDto } from './dto/createOrders.dto';
import { GetOrdersDto } from './dto/getOrders.dto';

@Injectable()
export class OrdersService {
  constructor(
    @InjectModel(Orders.name)
    private ordersModel: mongoose.Model<Orders>,
  ) {}
  createOrders(createOrdersDto: CreateOrdersDto) {
    const newOrders = new this.ordersModel(createOrdersDto);
    return newOrders.save();
  }
  getOrders() {
    return this.ordersModel.find();
  }
  // getOrdersByEmail(email: string) {
  //   return this.ordersModel.find({ email: email });
  // }
}
