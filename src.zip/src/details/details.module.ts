import { Module } from '@nestjs/common';
import { DetailsService } from './details.service';

import { DetailsController } from './details.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Details, DetailsSchema } from 'src/schemas/details.scheme';

@Module({
  providers: [DetailsService],
  imports: [
    MongooseModule.forFeature([
      {
        name: Details.name,
        schema: DetailsSchema,
      },
    ]),
  ],
  controllers: [DetailsController],
})
export class DetailsModule {}




