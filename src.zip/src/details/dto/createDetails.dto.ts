import { IsNotEmpty, IsString, IsNumber, IsEmpty } from 'class-validator';
//import { User } from "src/schemas/user.scheme";

export class CreateDetailsDto {
  @IsString()
  @IsNotEmpty()
  houseName: string;

  @IsString()
  @IsNotEmpty()
  roadName: string;

  @IsNotEmpty()
  @IsString()
  pincode: string;

  @IsNotEmpty()
  @IsString()
  state: string;

  @IsNotEmpty()
  @IsString()
  city: string;

   @IsNotEmpty()
  @IsString()
  name: string;

  @IsNotEmpty()
  @IsNumber()
  phone: number;

  // @IsEmpty({ message: 'You cannot pass user id' })
  // readonly user: User;
}


