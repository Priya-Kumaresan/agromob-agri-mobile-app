import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import mongoose, { Model } from 'mongoose';
import { Details } from 'src/schemas/details.scheme';
// import { User } from 'src/schemas/user.scheme';
import { CreateDetailsDto } from './dto/createDetails.dto';

@Injectable()
export class DetailsService {
  constructor(
    @InjectModel(Details.name)
    private detailsModel: mongoose.Model<Details>,
  ) {}

  //async
  // createProfile(profile: Profile, user: User): Promise<Profile> {
  createDetails(createDetailsDto: CreateDetailsDto) {
    // const newProfile = Object.assign(profile, { user: user._id });
    // const res = await this.profileModel.create(newProfile);
    // return res;
    const newDetails = new this.detailsModel(createDetailsDto);
    return newDetails.save();
  }
}
