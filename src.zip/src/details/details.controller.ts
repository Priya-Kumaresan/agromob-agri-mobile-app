import { Body, Controller, Post, Req, UseGuards } from '@nestjs/common';
import mongoose from 'mongoose';
import { DetailsService } from './details.service';
import { CreateDetailsDto } from './dto/createDetails.dto';
// import { AuthGuard } from '@nestjs/passport';
// import { Profile } from 'src/schemas/profile.scheme';

@Controller('details')
export class DetailsController {
  constructor(private detailsService: DetailsService) {}

  @Post()
  //  @UseGuards(AuthGuard())
  // async
  createProfile(@Body() createDetailsDto: CreateDetailsDto) {
    //,@Req() req):Promise<Profile> {
    console.log(createDetailsDto);
    return this.detailsService.createDetails(createDetailsDto);
    //,req.user);
  }
}