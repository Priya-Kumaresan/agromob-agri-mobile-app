import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Param,
  Patch,
  Post,
} from '@nestjs/common';
import mongoose from 'mongoose';
import { CropsService } from './crops.service';
import { CreateCropsDto } from './dto/createCrops.dto';

@Controller('crops')
export class CropsController {
  constructor(private cropsService: CropsService) {}

  @Post()
  createCrops(@Body() createCropsDto: CreateCropsDto) {
    console.log(createCropsDto);
    return this.cropsService.createCrops(createCropsDto);
  }

  @Get()
  getCrops() {
    return this.cropsService.getCrops();
  }

  @Get(':email')
  async getCropsByEmail(@Param('email') email: string) {
    const crops = await this.cropsService.getCropsByEmail(email);
    if (!crops) throw new NotFoundException('This Farmer has No crops');
    return crops;
  }
}
