import { IsNotEmpty, IsInt, IsString, IsEmail } from 'class-validator';
import { isFloat64Array } from 'util/types';

export class GetCropsDto {
  @IsNotEmpty()
  @IsEmail({}, { message: 'Please enter correct email' })
  email: string;
}
