import { IsNotEmpty, IsInt, IsString, IsEmail } from 'class-validator';
import { isFloat64Array } from 'util/types';

export class CreateCropsDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  quantity: string;

  @IsNotEmpty()
  @IsString()
  pricePerKg: string;

  @IsNotEmpty()
  @IsString()
  cropType: string;

 @IsNotEmpty()
  @IsString()
  image: string;
  
  @IsNotEmpty()
  @IsEmail({}, { message: 'Please enter correct email' })
  email: string;
}
