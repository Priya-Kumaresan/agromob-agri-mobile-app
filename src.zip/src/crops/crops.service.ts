import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Crops } from 'src/schemas/crops.scheme';
import { CreateCropsDto } from './dto/createCrops.dto';
import { GetCropsDto } from './dto/getCrops.dto';

@Injectable()
export class CropsService {
  constructor(@InjectModel(Crops.name) private cropsModel: Model<Crops>) {}

  createCrops(createCropsDto: CreateCropsDto) {
    const newCrops = new this.cropsModel(createCropsDto);
    return newCrops.save();
  }
  getCrops() {
    return this.cropsModel.find();
  }
  getCropsByEmail(email: string) {
    return this.cropsModel.find({ email: email });
  }
}
